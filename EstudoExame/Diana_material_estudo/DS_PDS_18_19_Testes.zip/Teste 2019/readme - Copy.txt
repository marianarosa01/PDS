Compilar:

(Dentro da pasta 89348):
javac *.java


Correr:

(Dentro da pasta 89348):
java Nostrum