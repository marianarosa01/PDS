public interface Servico {
	public String nome();
	public String descricao();
	public double price();
}
