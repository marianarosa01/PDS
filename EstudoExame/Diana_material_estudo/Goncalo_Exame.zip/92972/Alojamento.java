public class Alojamento extends ServicoConcreto {

    public Alojamento (String name, String description, int price, int maxOcupation) {
        super(TipoServico.ALOJAMENTO, name, description, price, maxOcupation);
    }

    public Alojamento (String name, String description, int price) {
        this(name, description, price, 0);
    }
    
}