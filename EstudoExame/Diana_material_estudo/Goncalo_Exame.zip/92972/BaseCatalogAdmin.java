import java.util.Map;
import java.util.TreeMap;
import java.util.Iterator;

public class BaseCatalogAdmin implements CatalogAdmin {
    public TreeMap<String, Servico> catalogo;


    public BaseCatalogAdmin(){
        catalogo = new TreeMap<>();
    };
	
	public boolean registarServico(String codigo, Servico servico) {
        Servico s = catalogo.put(codigo, servico);
        CatalogAdminLog.notify(
            String.format(
                "registarServico (%s): %s",
                codigo,
                servico.toString()
            )
        );
        return s!=null;
    }

	public boolean verificarServico(String codigo) {
        return catalogo.containsKey(codigo);
    }

	public Servico selecionarServico(String codigo) {
        return catalogo.get(codigo);
    }

	public Servico removerServico(String codigo) {
        CatalogAdminLog.notify(
            String.format(
                "removerServico (%s): %s",
                codigo,
                catalogo.get(codigo)
            )
        );
        return catalogo.remove(codigo);
    }

    public Map<String, Servico> getServicos() {
        return catalogo;
    }

    public Iterator<String> iterator() {
        return new CatalogAdminIterator(this);
    }
    
}
