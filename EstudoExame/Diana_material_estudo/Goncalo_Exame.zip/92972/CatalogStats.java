public class CatalogStats {

    private CatalogAdmin catalogo;

    public CatalogStats(CatalogAdmin catalogo) {
        this.catalogo = catalogo;
    }

    public String getAveragePriveActivities() {
        double priceSum = 0.0;
        int counter = 0;
        for (Servico s:catalogo.getServicos().values()) {
            if(s.type()!=TipoServico.ALOJAMENTO && s.type()!=TipoServico.PACOTE) {
                priceSum+=s.price();
                counter++;
            }
        }
        return String.format("%.2f" ,priceSum/counter);
    }

    public Servico getMinimumPrice(TipoServico t) {
        Servico min = null;
        double minPrice = 999999.0;
        for (Servico s:catalogo.getServicos().values()) {
            if (s.type() == t && s.price()<minPrice)
                min = s;
        }
        return min;
    }




    
}