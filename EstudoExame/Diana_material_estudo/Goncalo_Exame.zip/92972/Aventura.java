public class Aventura extends ServicoConcreto {

    public Aventura (String name, String description, int price, int maxOcupation) {
        super(TipoServico.AVENTURA, name, description, price, maxOcupation);
    }

    public Aventura (String name, String description, int price) {
        this(name, description, price, 0);
    }
    
}