public class Passeio extends ServicoConcreto {

    public Passeio (String name, String description, int price, int maxOcupation) {
        super(TipoServico.PASSEIO, name, description, price, maxOcupation);
    }

    public Passeio (String name, String description, int price) {
        this(name, description, price, 0);
    }
    
}