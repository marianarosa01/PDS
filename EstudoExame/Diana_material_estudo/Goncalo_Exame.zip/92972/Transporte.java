public class Transporte extends ServicoConcreto {

    public Transporte (String name, String description, int price, int maxOcupation) {
        super(TipoServico.TRANSPORTE, name, description, price, maxOcupation);
    }

    public Transporte (String name, String description, int price) {
        this(name, description, price, 0);
    }
    
}