public enum TipoServico {
    ALOJAMENTO,
    PASSEIO,
    AVENTURA,
    MUNDORURAL,
    TRANSPORTE,
    PACOTE
}