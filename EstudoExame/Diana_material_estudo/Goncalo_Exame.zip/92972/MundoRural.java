public class MundoRural extends ServicoConcreto {

    public MundoRural (String name, String description, int price, int maxOcupation) {
        super(TipoServico.MUNDORURAL, name, description, price, maxOcupation);
    }

    public MundoRural (String name, String description, int price) {
        this(name, description, price, 0);
    }
    
}