import java.util.List;
import java.util.ArrayList;

public class CatalogAdminLog {

    private static List<String> log = new ArrayList<>();

    public static void notify(String message) {
        log.add(message);
    }

    public static String getLog() {
        StringBuilder sb = new StringBuilder();
        for (String m:log) {
            sb.append(m);
            sb.append("\n");
        }
        return sb.toString();
    }
}