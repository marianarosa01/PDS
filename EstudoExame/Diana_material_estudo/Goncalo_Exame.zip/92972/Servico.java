public interface Servico {
	public String name();
	public String description();
	public double price();
	public TipoServico type();
}
