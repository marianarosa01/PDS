import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;

public class PacoteServicos implements Servico{

    private String name;
    private String description;
    private List<Servico> pacote;

    public PacoteServicos (String name, String description) {
        this.name = name;
        this.description = description;
        this.pacote = new ArrayList<>();
    }

    public void add(Servico s) {
        pacote.add(s);
    }

    public String name() {
        return this.name;
    }
	public String description() {
        return this.description;
    }

	public double price() {
        int discount = getDesconto();
        double price = 0;
        for (Servico s : pacote) {
            price += s.price()*((double)(100-discount)/100);
        }
        return price;
    }

	public TipoServico type() {
        return TipoServico.PACOTE;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(
            String.format(
                "Pacote com %d AbstractServicos de %d tipos. Preço (desconto = %d%%): %.1f\n",
                pacote.size(),
                getNumeroTipos(),
                getDesconto(),
                price()
            )
        );
        for (Servico s:pacote) {
            sb.append( 
                String.format(
                    "\t%s\n",
                    s.toString()
                )
            );
        }
        sb.setLength(sb.length() - 2);
        return sb.toString();
    }

    private int getDesconto() {
        return pacote.size()*3<10 ? pacote.size()*3 : 10;
    }

    private int getNumeroTipos() {
        Set<String> tipos = new HashSet<>();
        for (Servico s: pacote) {
            tipos.add(s.getClass().getName());
        }
        return tipos.size();
    }
}