import java.util.Iterator;

public class CatalogAdminIterator implements Iterator<String> {
    
    private CatalogAdmin catalogo;
    private Iterator<String> chaves;
    
    public CatalogAdminIterator(CatalogAdmin catalogo) {
        this.catalogo = catalogo;
        this.chaves = catalogo.getServicos().keySet().iterator();
    }

    public boolean hasNext() {
        return chaves.hasNext();
    }

    public String next() {
        if (!this.hasNext()) {
            System.exit(0);
            return null;
        }
        String codigo = chaves.next();
        return String.format(
            "Código %s : %s",
            codigo,
            catalogo.getServicos().get(codigo).toString()
        );                
    }
}