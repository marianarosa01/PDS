public class ServicoConcreto implements Servico {

    private String name;
    private String description;
    private double price;
    private TipoServico type;
    private int maxOcupation;

    public ServicoConcreto (TipoServico type, String name, String description, int price, int maxOcupation) {
        this.type = type;
        this.name = name;
        this.description = description;
        this.price = (double)price;
        this.maxOcupation = maxOcupation;
    }

    public ServicoConcreto (TipoServico type, String name, String description, int price) {
        this(type, name, description, price, 0);
    }

    public String name() {
        return this.name;
    }
	public String description() {
        return this.description;
    }

	public double price() {
        return this.price;
    }

	public TipoServico type() {
        return this.type;
    }

    public int maxOcupation () {
        return this.maxOcupation;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(
            String.format(
                "%s [name = %s, description = %s, price = %.1f]",
                type,
                name,
                description,
                price
            )
        );
        if (maxOcupation!=0) {
            sb.append(
                String.format(
                    "[ ocupação máxima : %d ]",
                    maxOcupation
                )
            );
        }
        return sb.toString();
    }
     
}